<?php
$servername = "";
$username = "";
$password = "";
$dbname = "";

