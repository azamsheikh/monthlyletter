<?php
include 'sql.php';

//$user_name = $_GET['username'];
    
 $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}    
        
$sql = "SELECT message,monthletter_ftostatus.username ,monthletter_messages_status_messages.status
FROM monthletter_messages
INNER JOIN monthletter_ftostatus 
ON monthletter_messages.conversationid = monthletter_ftostatus.conversationid
INNER JOIN monthletter_messages_status_messages
ON monthletter_ftostatus.tousername  = '$user_name'
INNER JOIN monthletter_userDetails
ON monthletter_messages.messageId  = monthletter_messages_status_messages.messageid
GROUP BY monthletter_messages.messageId
ORDER BY monthletter_ftostatus.tousername
";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  
  
  while($row = $result->fetch_assoc()) {
      if($row["status"] == "close")
      {
         // echo "Message: " . "close". " - From: " . $row["username"]. "<br><br><br>"; 
      }
      else{
    echo "" . $row["message"]. "<br>From: " . $row["username"]. "<br><br><br>";
      }
  }
  
  
} else {
  echo "0-0 results";
}
$conn->close();
    
    
   // die();
    
    
