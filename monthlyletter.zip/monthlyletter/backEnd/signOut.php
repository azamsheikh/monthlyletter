<?php
setcookie('mltuser', "", time() + (86400 * 30), "/"); // 86400 = 1 day
setcookie('mltuserpass', "", time() + (86400 * 30), "/"); // 86400 = 1 day