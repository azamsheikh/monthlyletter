<?php
$str = $_GET['string'];
$salt = 'uptownfunk';
echo sprintf(md5($str.$salt));

                          
?>