<?php
$message = $_GET['message'];

include 'sql.php';

include 'sendingStatus.php';



if($status == "close"){
    $canSend = 0;
echo " not done"; 
    
    die();
    
}


else if($status == "open"){
    $canSend = 1;
    
 $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}    
        
 $sql = "INSERT INTO monthletter_messages (message, conversationid)
VALUES ('$message', '$conversationid')";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}


 $sql = "Update monthletter_ftostatus set status = 'close' WHERE conversationid = $conversationid";

if ($conn->query($sql) === TRUE) {
  echo "update successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}






$conn->close();   
    
    
    
    die();
    
    
}