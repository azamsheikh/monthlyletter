<?php

$sender = $_COOKIE['mltuser'];
$receiver = $_GET['receiver'];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

////////////////searching for sender start////////////////
$sql = "SELECT id FROM monthletter_userDetails WHERE username= '$sender'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
   $senderavailable = "yes";
  }
 else {
   $senderavailable = "no";
   echo "user sender not found";
  }

/////////////searching for sender end////////////////




////////////////searching for receiver start////////////////
$sql = "SELECT id FROM monthletter_userDetails WHERE username= '$receiver'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
   $receiveravailable = "yes";
  }
 else {
   $receiveravailable = "no";
   echo "user receiver not found";
   
}
/////////////searching for receiver end////////////////




////////////////restriction check start////////////////
// Create connection

if($senderavailable == "yes" && $receiveravailable == "yes")
{

$sql = "SELECT conversationid, status FROM monthletter_ftostatus WHERE username='$sender' AND tousername ='$receiver'";
$result = $conn->query($sql);

if ($result->num_rows > 0) 
{
  // output data of each row
  while($row = $result->fetch_assoc()) 
  {
   $conversationid = $row["conversationid"];      
   $status = $row["status"];
  }
} 

else 
{
 $timestamp = date('Y-m-d');   
$sql = "INSERT INTO monthletter_ftostatus (username, tousername,lastdate, status)
VALUES ('$sender', '$receiver', '$timestamp' , 'open')";

if ($conn->query($sql) === TRUE) {
  echo "record created successfully";
}

else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$sql = "SELECT conversationid, status FROM monthletter_ftostatus WHERE username='$sender' AND tousername ='$receiver'";
$result = $conn->query($sql);

if ($result->num_rows > 0) 
{
  // output data of each row
  while($row = $result->fetch_assoc()) 
  {
   $conversationid = $row["conversationid"];      
   $status = $row["status"];
  }
} 
else
{
 die();   
}



 
}

$conn->close();   

}

else
{
 die();   
}


/////////////srestriction check end////////////////










?> 