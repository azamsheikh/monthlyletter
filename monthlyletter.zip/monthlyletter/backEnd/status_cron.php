<?php
$servername = "";
$username = "";
$password = "";
$dbname = "";


//gettin actual duration

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT duration FROM monthletter_cron_interval";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
   $duration = $row["duration"];  
  //echo "duration". $row["duration"];
  }
}




//////

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT conversationid, lastdate FROM monthletter_ftostatus";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
      
   $datetime1 = date_create($row["lastdate"]);
   $datetime2 = date_create(date("Y-m-d"));
   $interval = date_diff($datetime1, $datetime2);
   $difference = $interval ->format('%a');
   echo $row["conversationid"] . "<br>";
   echo $difference . "<br>" . "<br>";     
 
    $con = $row["conversationid"]; 
 

if($difference > $duration)
 {
       // Create connection
      $conn = new mysqli($servername, $username, $password, $dbname);
      // Check connection
      if ($conn->connect_error) {
       die("Connection failed: " . $conn->connect_error);
       }
        
        $sql = "UPDATE monthletter_ftostatus SET status='open' WHERE conversationid = '$con'";

        if ($conn->query($sql) === TRUE) {
       echo "Record updated successfully" . "<br>" . "<br>";
        } else {
        echo "Error updating record: " . $conn->error;
        }

         $conn->close();  

   }



else{
     // Create connection
     $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
     }

     $sql = "UPDATE ftostatus SET status='close' WHERE conversationid = '$con'";

    if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
   } else {
    echo "Error updating record: " . $conn->error;
   }

   $conn->close();    

   }

   
   
   
   
   
   
   
   
      
      
      
      
      
      
      
      
      
      
      
      
    
  }
} else {
  echo "0 results";
}
$conn->close();
///////////////////////////////////////////////////////////////////















//////////////receving restriction///////



include 'sql.php';


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT creation_date, messageid FROM status_messages";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
      
   $datetime1 = date_create($row["creation_date"]);
   $datetime2 = date_create(date("Y-m-d"));
   $interval = date_diff($datetime1, $datetime2);
   $difference = $interval ->format('%a');
   
   $mid = $row["messageid"]; 
   echo  "<br>message id : " . $row["messageid"] . "<br>";
   echo $difference . "<br>";     
   
   if($difference > $duration)
{
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
  
  $sql = "UPDATE status_messages SET status='open' WHERE messageid = '$mid'";

if ($conn->query($sql) === TRUE) {
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . $conn->error;
}

$conn->close();  

}



else{
 // Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "UPDATE status_messages SET status='close' WHERE messageid = '$mid'";

if ($conn->query($sql) === TRUE) {
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . $conn->error;
}

$conn->close();    
echo "here";
}

   
   
   
   
   
   
   
   
      
      
      
      
      
      
      
      
      
      
      
      
    
  }
} else {
  echo "0 results";
}
$conn->close();
///////////////////////////////////////////////////////////////////


?>