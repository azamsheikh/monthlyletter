<?php


if(!isset($_COOKIE['mltuser']) || !isset($_COOKIE['mltuserpass'])) 
{
 header('Location: login.php');
} 

else 
{
  include '../backEnd/sql.php';
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$user = $_COOKIE['mltuser'];
$pass = $_COOKIE['mltuserpass'];

$sql = "SELECT password FROM monthletter_userDetails WHERE username = '$user'";
$result = $conn->query($sql);

if ($result->num_rows > 0) 
{
  // output data of each row
  while($row = $result->fetch_assoc()) 
  {
      
      $retPass = $row["password"];
    
  }
  
  if( sprintf(md5($pass.'helloWorld')) == $retPass )
      {
     
       $user_name = $_COOKIE['mltuser'];

       include '../backEnd/readMessage.php'; 
      }
      
      else
      {   
           header('Location: login.php');
          die();
      }
  
} 

else {
  echo "0 results";
  header('Location: login.php');
}







 

 
 
    

}


?>

 <!DOCTYPE html>
<html>
<body>

<form action="../backEnd/message.php">
  <label for="touser">TO:</label><br>
  <input type="text" id="touser" name="receiver"><br>
  <label for="tomessage">Message:</label><br>
  <input type="text" id="tomessage" name="message"><br><br>
  <input type="submit" value="Send">
</form>
</body>
</html>

