 <form action="action_page.php">
  <label for="user">Username:</label><br>
  <input type="text" id="user" name="user"><br>
  <label for="pass">Password:</label><br>
  <input type="password" id="pass" name="pass"><br><br>
  <input type="submit" value="Login">
</form> 