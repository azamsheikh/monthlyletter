 <?php
$user = $_GET['user'];
$pass = $_GET['pass'];

setcookie('mltuser', $user, time() + (86400 * 30), "/"); // 86400 = 1 day
setcookie('mltuserpass', $pass, time() + (86400 * 30), "/"); // 86400 = 1 day

header('Location: index.php');
?>


